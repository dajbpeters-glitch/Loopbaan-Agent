# BaanMatchmaker 2.0 – modulaire MVP

Deze versie is een werkende modulaire MVP rond een herbruikbaar **Loopbaan-DNA**.

## Onderdelen

- **Profiler** – maakt één compact Loopbaan-DNA.
- **Explorer** – ontwikkelt werkvelden, opgaven en zoekclusters.
- **Scout** – haalt vacatures op via Adzuna en doet lokale voorselectie.
- **Matcher** – beoordeelt de feitelijke opdracht en overdraagbaarheid.
- **Coach** – helpt bij positionering en sollicitatiekeuze.
- **Learner** – leidt voorkeurspatronen af uit feedback.

## Structuur

```text
app.py
agents/
services/
models/
utils/
requirements.txt
README.md
.gitignore
```

## Streamlit secrets

Voeg in Streamlit Cloud toe:

```toml
ANTHROPIC_API_KEY = "..."
ADZUNA_APP_ID = "..."
ADZUNA_APP_KEY = "..."

# Optioneel:
ANTHROPIC_MODEL = "claude-haiku-4-5-20251001"
```

## Starten

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Waarom goedkoper en stabieler?

- Brondocumenten worden alleen verwerkt bij het maken van het Loopbaan-DNA.
- DNA, exploratie en vacaturematches worden gecachet in SQLite.
- Alleen de meest relevante vacatures krijgen een AI-beoordeling.
- Coach wordt alleen op verzoek aangeroepen.
- Zoektermen en AI-beoordelingen zijn begrensd.

## Opslag

De app gebruikt lokaal:

```text
baanmatchmaker.db
```

Op gratis Streamlit Cloud kan lokale opslag bij een herstart verdwijnen.
Voor een volgende versie is Supabase of PostgreSQL logischer.
