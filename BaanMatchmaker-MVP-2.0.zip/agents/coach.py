import json

from services.ai_client import AIClient


class CoachAgent:
    def __init__(self, ai: AIClient) -> None:
        self.ai = ai

    def run(self, career_dna: dict, job: dict, match: dict) -> dict:
        system_prompt = """
Je bent de Coach-agent van BaanMatchmaker.
Je vertaalt een inhoudelijke match naar een eerlijke, overtuigende uitleg voor
de kandidaat. Je overdrijft niet en helpt zowel bij keuze als positionering.
"""

        user_prompt = f"""
LOOPBAAN-DNA:
{json.dumps(career_dna, ensure_ascii=False)}

VACATURE:
Titel: {job.get('title', '')}
Organisatie: {job.get('company', {}).get('display_name', '')}
Omschrijving: {job.get('description', '')[:9000]}

MATCHER-UITKOMST:
{json.dumps(match, ensure_ascii=False)}

Geef uitsluitend geldig JSON:
{{
  "waarom_verrassend_passend": "...",
  "positioneringszin": "...",
  "drie_gesprekspunten": ["..."],
  "kritische_vragen_aan_werkgever": ["..."],
  "ontwikkelverhaal": "...",
  "sollicitatieadvies": "wel solliciteren / eerst bellen / niet prioriteren",
  "reden_advies": "..."
}}
"""
        return self.ai.ask_json(
            system_prompt,
            user_prompt,
            max_tokens=1100,
        )
