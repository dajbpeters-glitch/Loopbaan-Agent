import json

from services.ai_client import AIClient


class LearnerAgent:
    def __init__(self, ai: AIClient) -> None:
        self.ai = ai

    def run(self, career_dna: dict, feedback: list[dict]) -> dict:
        system_prompt = """
Je bent de Learner-agent van BaanMatchmaker.
Je leidt uit expliciete gebruikersfeedback voorzichtige voorkeurspatronen af.
Je wijzigt nooit feiten uit het Loopbaan-DNA en maakt onzekerheid zichtbaar.
"""

        user_prompt = f"""
BESTAAND LOOPBAAN-DNA:
{json.dumps(career_dna, ensure_ascii=False)}

FEEDBACK:
{json.dumps(feedback, ensure_ascii=False)}

Geef uitsluitend geldig JSON:
{{
  "geleerde_voorkeuren": ["..."],
  "waarschijnlijke_afkeer": ["..."],
  "nieuwe_hypotheses": ["..."],
  "niet_genoeg_bewijs_voor": ["..."],
  "advies_aan_explorer": ["..."],
  "advies_aan_matcher": ["..."]
}}
"""
        return self.ai.ask_json(
            system_prompt,
            user_prompt,
            max_tokens=900,
        )
