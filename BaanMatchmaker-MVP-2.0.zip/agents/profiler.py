import json

from services.ai_client import AIClient


class ProfilerAgent:
    def __init__(self, ai: AIClient) -> None:
        self.ai = ai

    def run(self, profile_text: str, career_move: str) -> dict:
        system_prompt = """
Je bent de Profiler-agent van BaanMatchmaker.
Je analyseert loopbaaninformatie zorgvuldig en maakt een compact, stabiel
Loopbaan-DNA. Je onderscheidt feiten, interpretaties en aannames. Je maakt
geen functietitel tot identiteit en zoekt naar overdraagbaarheid.
"""

        user_prompt = f"""
Maak op basis van de onderstaande broninformatie één compact Loopbaan-DNA.
Het DNA wordt later hergebruikt; neem daarom alleen relevante informatie op
en vermijd herhaling.

BRONPROFIEL:
{profile_text[:45000]}

GEWENSTE LOOPBAANBEWEGING:
{career_move}

Geef uitsluitend geldig JSON:
{{
  "identiteit": {{
    "professionele_kern": "...",
    "drijfveren": ["..."],
    "waarden": ["..."]
  }},
  "ervaring": {{
    "domeinen": ["..."],
    "verantwoordelijkheden": ["..."],
    "aantoonbare_resultaten": ["..."],
    "senioriteitsniveau": "..."
  }},
  "overdraagbaar_vermogen": {{
    "competenties": ["..."],
    "patronen_die_breed_inzetbaar_zijn": ["..."],
    "bewijsregels": ["..."]
  }},
  "werkstijl": {{
    "leiderschap": ["..."],
    "samenwerking": ["..."],
    "besluitvorming": ["..."],
    "voorkeursomgeving": ["..."]
  }},
  "ambitie": {{
    "gewenste_beweging": ["..."],
    "meer_van": ["..."],
    "minder_van": ["..."],
    "harde_grenzen": ["..."]
  }},
  "context": {{
    "passende_opgaven": ["..."],
    "passende_organisaties": ["..."],
    "doelgroepen": ["..."]
  }},
  "aannames_en_leemtes": ["..."],
  "samenvatting": "maximaal 180 woorden"
}}
"""
        return self.ai.ask_json(
            system_prompt,
            user_prompt,
            max_tokens=1800,
        )
