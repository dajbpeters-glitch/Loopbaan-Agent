import json

from services.ai_client import AIClient


class ExplorerAgent:
    def __init__(self, ai: AIClient) -> None:
        self.ai = ai

    def run(self, career_dna: dict, feedback: list[dict]) -> dict:
        system_prompt = """
Je bent de Explorer-agent van BaanMatchmaker.
Je denkt in werkvelden, maatschappelijke opgaven, typen opdrachten en
organisatorische contexten. Je voorkomt dat bekende functietitels de
zoekruimte beperken. Je levert wel zoektermen voor vacaturebronnen, maar
alleen als praktische vertaling van bredere werkvelden.
"""

        feedback_text = "\n".join(
            f"- {item['judgement']}: {item.get('title')} – "
            f"{item.get('reason') or ''} {item.get('note') or ''}"
            for item in feedback
        ) or "Nog geen feedback."

        user_prompt = f"""
LOOPBAAN-DNA:
{json.dumps(career_dna, ensure_ascii=False)}

GEBRUIKERSFEEDBACK:
{feedback_text}

Ontwikkel een brede maar realistische zoekruimte. Denk eerst in werkvelden en
opgaven, pas daarna in zoektermen.

Geef uitsluitend geldig JSON:
{{
  "werkvelden": [
    {{
      "naam": "...",
      "waarom_passend": "...",
      "typen_opgaven": ["..."],
      "mogelijke_organisaties": ["..."],
      "spanningsveld": "..."
    }}
  ],
  "onverwachte_richtingen": [
    {{
      "richting": "...",
      "brugredenering": "...",
      "wat_nog_bewezen_moet_worden": "..."
    }}
  ],
  "zoekclusters": [
    {{
      "cluster": "...",
      "zoektermen": ["maximaal 6 concrete termen"],
      "inhoudelijke_signalen": ["woorden of thema's in vacatureteksten"]
    }}
  ],
  "vermijd_zoekvernauwing": ["..."],
  "prioriteiten": ["maximaal 5 meest kansrijke richtingen"]
}}
"""
        return self.ai.ask_json(
            system_prompt,
            user_prompt,
            max_tokens=1800,
        )
