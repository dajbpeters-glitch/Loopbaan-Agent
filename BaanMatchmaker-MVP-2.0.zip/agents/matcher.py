import json

from services.ai_client import AIClient
from utils.scores import clamp_score


class MatcherAgent:
    WEIGHTS = {
        "opdrachtmatch": 0.25,
        "bewijsuit_ervaring": 0.15,
        "overdraagbaarheid": 0.20,
        "contextmatch": 0.12,
        "waarden_en_werkstijl": 0.10,
        "voorwaarden_en_risico": 0.10,
        "ontwikkelpotentieel": 0.08,
    }

    def __init__(self, ai: AIClient) -> None:
        self.ai = ai

    def run(
        self,
        career_dna: dict,
        job: dict,
        feedback: list[dict],
    ) -> dict:
        system_prompt = """
Je bent de Matcher-agent van BaanMatchmaker.
Je vergelijkt het Loopbaan-DNA met de feitelijke vacature-opdracht.
De functietitel is slechts een label. Je beoordeelt bewijs, overdraagbaarheid,
context, risico's en voorwaarden. Je bent kritisch en vermijdt wensdenken.
"""

        feedback_text = "\n".join(
            f"- {item['judgement']}: {item.get('title')} – "
            f"{item.get('reason') or ''}"
            for item in feedback
        ) or "Nog geen feedback."

        title = job.get("title", "")
        organisation = job.get("company", {}).get("display_name", "")
        description = job.get("description", "")[:12000]

        user_prompt = f"""
LOOPBAAN-DNA:
{json.dumps(career_dna, ensure_ascii=False)}

GEBRUIKERSFEEDBACK:
{feedback_text}

VACATURE:
Titel: {title}
Organisatie: {organisation}
Omschrijving:
{description}

Beoordeel:
- opdrachtmatch
- bewijsuit_ervaring
- overdraagbaarheid
- contextmatch
- waarden_en_werkstijl
- voorwaarden_en_risico
- ontwikkelpotentieel

Gebruik scores van 0-100. Classificeer als:
"logische stap", "brugrol", "verrassende match" of "onvoldoende match".

Geef uitsluitend geldig JSON:
{{
  "scores": {{
    "opdrachtmatch": 0,
    "bewijsuit_ervaring": 0,
    "overdraagbaarheid": 0,
    "contextmatch": 0,
    "waarden_en_werkstijl": 0,
    "voorwaarden_en_risico": 0,
    "ontwikkelpotentieel": 0
  }},
  "classificatie": "...",
  "titel_is_misleidend": false,
  "sterke_bewijsregels": ["..."],
  "brugredenering": "...",
  "risicos": ["..."],
  "te_controleren": ["..."],
  "korte_conclusie": "maximaal 3 zinnen"
}}
"""

        result = self.ai.ask_json(
            system_prompt,
            user_prompt,
            max_tokens=1300,
        )

        scores = result.get("scores", {})
        normalized = {
            name: clamp_score(scores.get(name))
            for name in self.WEIGHTS
        }
        result["scores"] = normalized

        if all(value is not None for value in normalized.values()):
            result["totaalscore"] = round(
                sum(
                    normalized[name] * weight
                    for name, weight in self.WEIGHTS.items()
                )
            )
        else:
            result["totaalscore"] = None

        return result
