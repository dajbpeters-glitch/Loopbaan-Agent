from dataclasses import dataclass, field


@dataclass
class AppState:
    profile_text: str = ""
    career_move: str = ""
    career_dna: dict | None = None
    exploration: dict | None = None
    results: list[dict] = field(default_factory=list)
