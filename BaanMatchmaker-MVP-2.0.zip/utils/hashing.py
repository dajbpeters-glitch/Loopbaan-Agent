import hashlib


def make_profile_hash(profile_text: str, career_move: str) -> str:
    source = f"{profile_text}\n---\n{career_move}"
    return hashlib.sha256(source.encode("utf-8")).hexdigest()
