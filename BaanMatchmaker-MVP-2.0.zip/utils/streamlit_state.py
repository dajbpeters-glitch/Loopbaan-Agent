import streamlit as st


DEFAULTS = {
    "profile_text": "",
    "career_move": (
        "Ik zoek een volgende stap waarin mijn brede ervaring betekenisvol "
        "kan worden ingezet. De werkelijke opdracht en maatschappelijke opgave "
        "zijn belangrijker dan een bekende functietitel."
    ),
    "career_dna": None,
    "exploration": None,
    "results": [],
    "match_overview": [],
    "learning_profile": None,
    "location": "Boxtel",
    "radius": 40,
    "jobs_per_term": 10,
    "max_search_terms": 12,
    "max_ai_matches": 30,
    "minimum_score": 55,
}


def init_state() -> None:
    for key, value in DEFAULTS.items():
        if key not in st.session_state:
            st.session_state[key] = value
