def normalize(text: str) -> str:
    return " ".join((text or "").lower().split())


def unique_preserve_order(values: list[str]) -> list[str]:
    return list(dict.fromkeys(
        value.strip()
        for value in values
        if isinstance(value, str) and value.strip()
    ))
