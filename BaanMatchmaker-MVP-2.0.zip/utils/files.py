from docx import Document
from pypdf import PdfReader


def read_pdf(file) -> str:
    reader = PdfReader(file)
    return "\n".join(page.extract_text() or "" for page in reader.pages)


def read_docx(file) -> str:
    document = Document(file)
    return "\n".join(paragraph.text for paragraph in document.paragraphs)


def read_file(file) -> str:
    name = file.name.lower()

    if name.endswith(".pdf"):
        return read_pdf(file)

    if name.endswith(".docx"):
        return read_docx(file)

    return file.read().decode("utf-8", errors="ignore")


def read_uploaded_files(files) -> str:
    parts = [read_file(file) for file in files]
    return "\n\n--- DOCUMENT ---\n\n".join(parts)
