import json
import sqlite3
from datetime import datetime


class Database:
    def __init__(self, path: str) -> None:
        self.path = path

    def connect(self):
        return sqlite3.connect(self.path)

    def initialize(self) -> None:
        with self.connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS career_dna (
                    profile_key TEXT PRIMARY KEY,
                    source_profile TEXT NOT NULL,
                    career_move TEXT NOT NULL,
                    dna_json TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS explorations (
                    profile_key TEXT PRIMARY KEY,
                    exploration_json TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS matches (
                    profile_key TEXT NOT NULL,
                    job_id TEXT NOT NULL,
                    job_hash TEXT NOT NULL,
                    match_json TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    PRIMARY KEY (profile_key, job_id, job_hash)
                );

                CREATE TABLE IF NOT EXISTS feedback (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    profile_key TEXT NOT NULL,
                    job_id TEXT NOT NULL,
                    title TEXT,
                    organisation TEXT,
                    judgement TEXT NOT NULL,
                    reason TEXT,
                    note TEXT,
                    created_at TEXT NOT NULL
                );
                """
            )
            conn.commit()

    def save_career_dna(
        self,
        profile_key: str,
        source_profile: str,
        career_move: str,
        dna: dict,
    ) -> None:
        with self.connect() as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO career_dna
                (profile_key, source_profile, career_move, dna_json, created_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    profile_key,
                    source_profile,
                    career_move,
                    json.dumps(dna, ensure_ascii=False),
                    datetime.now().isoformat(timespec="seconds"),
                ),
            )
            conn.commit()

    def get_career_dna(self, profile_key: str) -> dict | None:
        with self.connect() as conn:
            row = conn.execute(
                "SELECT dna_json FROM career_dna WHERE profile_key = ?",
                (profile_key,),
            ).fetchone()
        return json.loads(row[0]) if row else None

    def save_exploration(self, profile_key: str, exploration: dict) -> None:
        with self.connect() as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO explorations
                (profile_key, exploration_json, created_at)
                VALUES (?, ?, ?)
                """,
                (
                    profile_key,
                    json.dumps(exploration, ensure_ascii=False),
                    datetime.now().isoformat(timespec="seconds"),
                ),
            )
            conn.commit()

    def get_exploration(self, profile_key: str) -> dict | None:
        with self.connect() as conn:
            row = conn.execute(
                """
                SELECT exploration_json
                FROM explorations
                WHERE profile_key = ?
                """,
                (profile_key,),
            ).fetchone()
        return json.loads(row[0]) if row else None

    def save_match(
        self,
        profile_key: str,
        job_id: str,
        job_hash: str,
        match: dict,
    ) -> None:
        with self.connect() as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO matches
                (profile_key, job_id, job_hash, match_json, created_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    profile_key,
                    job_id,
                    job_hash,
                    json.dumps(match, ensure_ascii=False),
                    datetime.now().isoformat(timespec="seconds"),
                ),
            )
            conn.commit()

    def get_match(
        self,
        profile_key: str,
        job_id: str,
        job_hash: str,
    ) -> dict | None:
        with self.connect() as conn:
            row = conn.execute(
                """
                SELECT match_json
                FROM matches
                WHERE profile_key = ? AND job_id = ? AND job_hash = ?
                """,
                (profile_key, job_id, job_hash),
            ).fetchone()
        return json.loads(row[0]) if row else None

    def save_feedback(
        self,
        profile_key: str,
        job_id: str,
        title: str,
        organisation: str,
        judgement: str,
        reason: str,
        note: str,
    ) -> None:
        with self.connect() as conn:
            conn.execute(
                """
                INSERT INTO feedback
                (profile_key, job_id, title, organisation,
                 judgement, reason, note, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    profile_key,
                    job_id,
                    title,
                    organisation,
                    judgement,
                    reason,
                    note,
                    datetime.now().isoformat(timespec="seconds"),
                ),
            )
            conn.commit()

    def get_feedback(self, profile_key: str, limit: int = 20) -> list[dict]:
        with self.connect() as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                """
                SELECT job_id, title, organisation, judgement, reason, note
                FROM feedback
                WHERE profile_key = ?
                ORDER BY id DESC
                LIMIT ?
                """,
                (profile_key, limit),
            ).fetchall()
        return [dict(row) for row in rows]

    def delete_feedback(self, profile_key: str) -> None:
        with self.connect() as conn:
            conn.execute(
                "DELETE FROM feedback WHERE profile_key = ?",
                (profile_key,),
            )
            conn.commit()
