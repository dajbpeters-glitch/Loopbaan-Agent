import hashlib
import json

import requests
import streamlit as st

from utils.text import normalize


class AdzunaJobSource:
    URL = "https://api.adzuna.com/v1/api/jobs/nl/search/1"

    @staticmethod
    def _secret(name: str) -> str:
        try:
            return st.secrets[name]
        except Exception as exc:
            raise KeyError(f"Ontbrekende Streamlit secret: {name}") from exc

    def search(
        self,
        term: str,
        location: str,
        radius: int,
        results_per_term: int,
    ) -> list[dict]:
        response = requests.get(
            self.URL,
            params={
                "app_id": self._secret("ADZUNA_APP_ID"),
                "app_key": self._secret("ADZUNA_APP_KEY"),
                "what": term,
                "where": location,
                "distance": radius,
                "results_per_page": results_per_term,
                "content-type": "application/json",
            },
            timeout=25,
        )
        response.raise_for_status()
        return response.json().get("results", [])

    @staticmethod
    def job_key(job: dict) -> str:
        return str(job.get("id") or normalize(
            f"{job.get('title', '')}|"
            f"{job.get('company', {}).get('display_name', '')}"
        ))

    @staticmethod
    def job_id(job: dict) -> str:
        return str(job.get("id") or AdzunaJobSource.job_key(job))

    @staticmethod
    def job_hash(job: dict) -> str:
        source = json.dumps(
            {
                "title": job.get("title"),
                "company": job.get("company", {}).get("display_name"),
                "description": job.get("description"),
            },
            ensure_ascii=False,
            sort_keys=True,
        )
        return hashlib.sha256(source.encode("utf-8")).hexdigest()

    @staticmethod
    def local_score(job: dict, signals: list[str]) -> int:
        text = normalize(
            " ".join(
                [
                    job.get("title", ""),
                    job.get("description", ""),
                    job.get("company", {}).get("display_name", ""),
                    job.get("category", {}).get("label", ""),
                ]
            )
        )

        score = 1 if job.get("description") else 0

        for signal in signals:
            if normalize(signal) in text:
                score += 2

        return score
