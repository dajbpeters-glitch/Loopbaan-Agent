import json
import re

import anthropic
import streamlit as st


class AIClient:
    def __init__(self) -> None:
        self._client = anthropic.Anthropic(
            api_key=self._secret("ANTHROPIC_API_KEY"),
            timeout=60.0,
            max_retries=2,
        )
        self._model = self._secret(
            "ANTHROPIC_MODEL",
            "claude-haiku-4-5-20251001",
        )

    @staticmethod
    def _secret(name: str, default: str | None = None) -> str:
        try:
            return st.secrets[name]
        except Exception:
            if default is not None:
                return default
            raise KeyError(f"Ontbrekende Streamlit secret: {name}")

    def ask_json(
        self,
        system_prompt: str,
        user_prompt: str,
        max_tokens: int = 1200,
    ) -> dict:
        response = self._client.messages.create(
            model=self._model,
            max_tokens=max_tokens,
            temperature=0,
            system=system_prompt,
            messages=[{"role": "user", "content": user_prompt}],
        )

        if not response.content:
            raise ValueError("De AI gaf geen inhoud terug.")

        return self._extract_json(response.content[0].text)

    @staticmethod
    def _extract_json(text: str) -> dict:
        text = (text or "").strip()

        if not text:
            raise ValueError("De AI gaf een leeg antwoord terug.")

        text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.IGNORECASE)
        text = re.sub(r"\s*```$", "", text)

        try:
            return json.loads(text)
        except json.JSONDecodeError:
            match = re.search(r"\{.*\}", text, flags=re.DOTALL)
            if not match:
                raise ValueError(
                    "De AI gaf geen geldig JSON-object terug. "
                    f"Eerste deel: {text[:250]}"
                )

            try:
                return json.loads(match.group(0))
            except json.JSONDecodeError as exc:
                raise ValueError(
                    "Het gevonden JSON-object kon niet worden gelezen. "
                    f"Eerste deel: {match.group(0)[:250]}"
                ) from exc
